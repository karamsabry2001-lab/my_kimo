# مساعدي الشخصي (Smart Assistant)

تطبيق Flutter لأندرويد: مساعد مالي وصحي يعمل **بدون إنترنت** ويحفظ البيانات على الهاتف (SQLite).

## المميزات
- **الرئيسية:** أقرب ميعاد دواء، ميعاد المستشفى القادم، حالة الجمعيات (حسابي / الوالدة)، وتنبيه نفاد الأدوية.
- **الجمعيات الشهرية:** قسمان (حسابي / حساب الوالدة) – إضافة وتعديل وحذف، جدول أقساط مع تحديد المدفوع، دور القبض.
- **مواعيد المستشفيات:** التاريخ واليوم والساعة والطبيب والمكان والملاحظات.
- **الأدوية:** الاسم، الجرعة، المدة، الساعات (أكثر من ساعة)، أيام الأسبوع، الملاحظات، نشط/منتهي، مخزون العلبة وتنبيه اقتراب النفاد.
- **الأرشيف:** صور الروشتات والتقارير والتحاليل وملفات PDF (كاميرا / معرض / ملفات).
- **تنبيهات محلية** للأدوية والمواعيد والجمعيات.
- **بحث وفلترة** داخل كل قسم.
- **نسخ احتياطي واستيراد** (ملف ZIP يحتوي البيانات والمرفقات).
- **مشاركة** تفاصيل المواعيد والأدوية والجمعيات.
- **وضع ليلي / نهاري** (زر في أعلى كل شاشة + الإعدادات).

## خطوات التشغيل

1. أنشئ مشروع Flutter جديد بنفس الاسم:
   ```bash
   flutter create --platforms=android --project-name smart_assistant smart_assistant
   cd smart_assistant
   ```
2. انسخ من هذا المجلد إلى مشروعك (استبدل الموجود):
   - `pubspec.yaml`
   - مجلد `lib/` بالكامل
3. احذف ملف الاختبار الافتراضي (يشير إلى كود قديم):
   ```bash
   rm test/widget_test.dart
   ```
4. انسخ `android_changes/AndroidManifest.xml` فوق
   `android/app/src/main/AndroidManifest.xml`
5. عدّل Gradle كما في `android_changes/gradle_changes.md` (تفعيل desugaring).
6. شغّل:
   ```bash
   flutter pub get
   flutter run
   ```
   ولبناء ملف APK:
   ```bash
   flutter build apk --release
   ```

## هيكل المشروع
```
pubspec.yaml
lib/
  main.dart                      نقطة البداية (RTL + عربي + الثيم)
  theme.dart
  db/database_helper.dart        SQLite
  models/                        association, appointment, medicine, document_item
  providers/app_state.dart       الحالة العامة + الإعدادات
  services/
    notification_service.dart    التنبيهات
    backup_service.dart          النسخ الاحتياطي والاستيراد
    file_service.dart            مرفقات الأرشيف
  utils/ helpers.dart, share_texts.dart
  widgets/common.dart
  screens/
    home_shell.dart  dashboard_screen.dart
    associations_screen.dart  association_form_screen.dart  association_detail_screen.dart
    appointments_screen.dart  appointment_form_screen.dart
    medicines_screen.dart     medicine_form_screen.dart
    archive_screen.dart       document_form_screen.dart
    settings_screen.dart
android_changes/                 AndroidManifest.xml + تعليمات Gradle
```

## ملاحظات مهمة
- **العملة:** `ج.م` وتُغيَّر من الثابت `kCurrency` في `lib/utils/helpers.dart`.
- **التنبيهات:** تُعاد جدولتها تلقائياً مع كل تعديل وعند فتح التطبيق. على أندرويد 12+ اضغط
  "السماح بالتنبيهات الدقيقة" من الإعدادات، وعلى بعض الهواتف (شاومي/أوبو/سامسونج) اسمح للتطبيق بالعمل في الخلفية.
- **الأدوية المستمرة** تُجدول بتنبيه متكرر، أما الأدوية ذات المدة المحددة فيُجدول لها تنبيه لكل جرعة (حتى 120 جرعة، ويُكمَّل عند فتح التطبيق).
- **النسخ الاحتياطي** يحفظ كل شيء في ملف ZIP؛ الاستيراد **يستبدل** البيانات الحالية.
- لم تتم تجربة بناء الكود على جهاز حقيقي أثناء كتابته. لو ظهر خطأ عند `flutter pub get` أو `flutter run` أرسله لي وأصلحه.
