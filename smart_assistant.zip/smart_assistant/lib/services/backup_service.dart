import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../db/database_helper.dart';
import '../utils/helpers.dart';
import 'file_service.dart';

/// النسخ الاحتياطي والاستيراد المحلي (ملف ZIP يحتوي البيانات + المرفقات).
class BackupService {
  static const String _dataEntry = 'data.json';
  static const String _attachmentsPrefix = 'attachments/';

  static String _fileName() {
    final n = DateTime.now();
    return 'smart_assistant_backup_${n.year}${two(n.month)}${two(n.day)}_${two(n.hour)}${two(n.minute)}.zip';
  }

  static Future<Uint8List> buildBackupBytes() async {
    final data = await DatabaseHelper.instance.exportAll();
    final jsonBytes = utf8.encode(jsonEncode({
      'app': 'smart_assistant',
      'version': 1,
      'createdAt': DateTime.now().toIso8601String(),
      'data': data,
    }));

    final archive = Archive();
    archive.addFile(ArchiveFile(_dataEntry, jsonBytes.length, jsonBytes));

    final dir = await FileService.attachmentsDir();
    for (final entity in dir.listSync()) {
      if (entity is! File) continue;
      final bytes = await entity.readAsBytes();
      archive.addFile(ArchiveFile(
        '$_attachmentsPrefix${p.basename(entity.path)}',
        bytes.length,
        bytes,
      ));
    }

    final encoded = ZipEncoder().encode(archive);
    return Uint8List.fromList(encoded ?? <int>[]);
  }

  /// حفظ النسخة في مكان يختاره المستخدم على الهاتف.
  /// يُرجع true عند النجاح، و false لو ألغى المستخدم.
  static Future<bool> saveBackupToDevice() async {
    final bytes = await buildBackupBytes();
    final name = _fileName();
    try {
      final result = await FilePicker.platform.saveFile(
        dialogTitle: 'حفظ النسخة الاحتياطية',
        fileName: name,
        bytes: bytes,
        type: FileType.custom,
        allowedExtensions: const ['zip'],
      );
      return result != null;
    } catch (_) {
      // في حال عدم دعم نافذة الحفظ نستخدم المشاركة بدلاً منها.
      await shareBackup(bytes: bytes, name: name);
      return true;
    }
  }

  /// مشاركة النسخة (واتساب، درايف، بلوتوث...).
  static Future<void> shareBackup({Uint8List? bytes, String? name}) async {
    final data = bytes ?? await buildBackupBytes();
    final fileName = name ?? _fileName();
    final tmp = await getTemporaryDirectory();
    final file = File(p.join(tmp.path, fileName));
    await file.writeAsBytes(data, flush: true);
    await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية - مساعدي الشخصي');
  }

  /// استيراد نسخة احتياطية (يستبدل البيانات الحالية).
  /// يُرجع true عند النجاح، و false لو ألغى المستخدم.
  static Future<bool> importBackup() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.any);
    if (picked == null || picked.files.isEmpty) return false;
    final path = picked.files.single.path;
    if (path == null) return false;

    final bytes = await File(path).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);

    final dataFile = archive.findFile(_dataEntry);
    if (dataFile == null) {
      throw const FormatException('الملف ليس نسخة احتياطية صالحة');
    }
    final decoded = jsonDecode(utf8.decode(dataFile.content as List<int>));
    if (decoded is! Map || decoded['app'] != 'smart_assistant' || decoded['data'] is! Map) {
      throw const FormatException('الملف ليس نسخة احتياطية صالحة');
    }

    // استبدال قاعدة البيانات أولاً (داخل transaction، فلو فشلت لا يتغير شيء).
    await DatabaseHelper.instance
        .importAll(Map<String, dynamic>.from(decoded['data'] as Map));

    // ثم استبدال المرفقات.
    final dir = await FileService.attachmentsDir();
    for (final entity in dir.listSync()) {
      if (entity is File) {
        try {
          await entity.delete();
        } catch (_) {}
      }
    }
    for (final f in archive.files) {
      if (!f.isFile || !f.name.startsWith(_attachmentsPrefix)) continue;
      final safeName = p.basename(f.name); // حماية من مسارات خبيثة
      if (safeName.isEmpty) continue;
      await File(p.join(dir.path, safeName))
          .writeAsBytes(f.content as List<int>, flush: true);
    }
    return true;
  }
}
