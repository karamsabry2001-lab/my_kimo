import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// إدارة ملفات المرفقات (الروشتات والمستندات) داخل مجلد التطبيق الخاص.
class FileService {
  static Future<Directory> attachmentsDir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'attachments'));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// نسخ ملف إلى مجلد التطبيق وإرجاع اسمه الجديد.
  static Future<String> importFile(String sourcePath) async {
    final dir = await attachmentsDir();
    final base = p.basename(sourcePath);
    final name = '${DateTime.now().millisecondsSinceEpoch}_$base';
    await File(sourcePath).copy(p.join(dir.path, name));
    return name;
  }

  static Future<File> resolve(String fileName) async {
    final dir = await attachmentsDir();
    return File(p.join(dir.path, p.basename(fileName)));
  }

  static Future<void> delete(String fileName) async {
    try {
      final f = await resolve(fileName);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
