import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../models/appointment.dart';
import '../models/association.dart';
import '../models/medicine.dart';
import '../utils/helpers.dart';

class _Channel {
  final String id;
  final String name;
  final String description;
  const _Channel(this.id, this.name, this.description);
}

const _chMeds = _Channel('meds_channel', 'تنبيهات الأدوية', 'مواعيد جرعات الأدوية');
const _chAppts =
    _Channel('appts_channel', 'تنبيهات المواعيد', 'مواعيد المستشفيات والعيادات');
const _chAssoc =
    _Channel('assoc_channel', 'تنبيهات الجمعيات', 'مواعيد دفع وقبض الجمعيات');

/// خدمة التنبيهات المحلية (تعمل بدون إنترنت وتبقى بعد إعادة تشغيل الهاتف).
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  int _idCounter = 1;

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Africa/Cairo'));
    }
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
    _initialized = true;
  }

  /// طلب إذن إظهار الإشعارات (أندرويد 13+).
  Future<void> requestPermissions() async {
    try {
      await _android?.requestNotificationsPermission();
    } catch (_) {}
  }

  /// طلب إذن المنبهات الدقيقة (أندرويد 12+) - يفتح صفحة الإعدادات.
  Future<void> requestExactAlarms() async {
    try {
      await _android?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  Future<bool> canScheduleExact() async {
    try {
      return await _android?.canScheduleExactNotifications() ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> showTest() async {
    await _plugin.show(
      0,
      'تنبيه تجريبي',
      'التنبيهات تعمل بشكل سليم ✅',
      _details(_chMeds, 'التنبيهات تعمل بشكل سليم ✅'),
    );
  }

  NotificationDetails _details(_Channel ch, String body) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        ch.id,
        ch.name,
        channelDescription: ch.description,
        importance: Importance.high,
        priority: Priority.high,
        styleInformation: BigTextStyleInformation(body),
      ),
    );
  }

  Future<void> _zoned({
    required String title,
    required String body,
    required DateTime when,
    required _Channel channel,
    required AndroidScheduleMode mode,
    DateTimeComponents? match,
  }) async {
    if (match == null && !when.isAfter(DateTime.now())) return;
    try {
      await _plugin.zonedSchedule(
        _idCounter++,
        title,
        body,
        tz.TZDateTime.from(when, tz.local),
        _details(channel, body),
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: match,
      );
    } catch (e) {
      debugPrint('Notification scheduling failed: $e');
    }
  }

  /// أقرب موعد (يوم + ساعة) بعد الآن. [weekday] اختياري (الاثنين=1 ... الأحد=7).
  DateTime? _nextOccurrence({
    int? weekday,
    required int hour,
    required int minute,
    DateTime? notBefore,
  }) {
    final now = DateTime.now();
    var start = dateOnly(now);
    if (notBefore != null && dateOnly(notBefore).isAfter(start)) {
      start = dateOnly(notBefore);
    }
    for (var i = 0; i < 8; i++) {
      final d = DateTime(start.year, start.month, start.day + i);
      if (weekday != null && d.weekday != weekday) continue;
      final dt = DateTime(d.year, d.month, d.day, hour, minute);
      if (dt.isAfter(now)) return dt;
    }
    return null;
  }

  /// إلغاء كل التنبيهات وإعادة جدولتها من البيانات الحالية.
  Future<void> rescheduleAll({
    required List<Medicine> medicines,
    required List<Appointment> appointments,
    required List<Association> associations,
    required bool meds,
    required bool appts,
    required bool assoc,
  }) async {
    if (!_initialized) await init();
    await _plugin.cancelAll();
    _idCounter = 1;

    final exact = await canScheduleExact();
    final mode = exact
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;

    if (meds) await _scheduleMedicines(medicines, mode);
    if (appts) await _scheduleAppointments(appointments, mode);
    if (assoc) await _scheduleAssociations(associations, mode);
  }

  Future<void> _scheduleMedicines(
      List<Medicine> medicines, AndroidScheduleMode mode) async {
    for (final m in medicines) {
      if (!m.isActive || m.times.isEmpty) continue;
      final body = m.dose.isEmpty ? m.name : '${m.name} - ${m.dose}';

      if (m.durationDays <= 0) {
        // دواء مستمر: تنبيه متكرر يومياً أو أسبوعياً.
        for (final t in m.timeList) {
          if (m.weekdays.isEmpty) {
            final when = _nextOccurrence(
                hour: t.hour, minute: t.minute, notBefore: m.startDate);
            if (when == null) continue;
            await _zoned(
              title: 'ميعاد الدواء 💊',
              body: body,
              when: when,
              channel: _chMeds,
              mode: mode,
              match: DateTimeComponents.time,
            );
          } else {
            for (final wd in m.weekdays) {
              final when = _nextOccurrence(
                  weekday: wd,
                  hour: t.hour,
                  minute: t.minute,
                  notBefore: m.startDate);
              if (when == null) continue;
              await _zoned(
                title: 'ميعاد الدواء 💊',
                body: body,
                when: when,
                channel: _chMeds,
                mode: mode,
                match: DateTimeComponents.dayOfWeekAndTime,
              );
            }
          }
        }
      } else {
        // دواء بمدة محددة: تنبيه لكل جرعة حتى نهاية المدة (بحد أقصى).
        var cursor = DateTime.now();
        for (var i = 0; i < 120; i++) {
          final next = m.nextDoseAfter(cursor);
          if (next == null) break;
          await _zoned(
            title: 'ميعاد الدواء 💊',
            body: body,
            when: next,
            channel: _chMeds,
            mode: mode,
          );
          cursor = next;
        }
      }

      // تنبيه يومي عند اقتراب نفاذ العلبة.
      if (m.isLowStock) {
        final days = m.stockDaysLeft;
        final left = m.pillsRemaining ?? 0;
        final when = _nextOccurrence(hour: 10, minute: 0);
        if (when != null) {
          await _zoned(
            title: 'اقترب نفاذ الدواء ⚠️',
            body: days == null
                ? '${m.name}: متبقي $left فقط. جهّز علبة جديدة.'
                : '${m.name}: متبقي $left (يكفي حوالي $days يوم). جهّز علبة جديدة.',
            when: when,
            channel: _chMeds,
            mode: mode,
            match: DateTimeComponents.time,
          );
        }
      }
    }
  }

  Future<void> _scheduleAppointments(
      List<Appointment> appointments, AndroidScheduleMode mode) async {
    for (final a in appointments) {
      if (a.done) continue;
      final title = a.title.isEmpty ? 'ميعاد عند ${a.doctor}' : '${a.title} - ${a.doctor}';
      final details =
          '${weekdayName(a.dateTime.weekday)} ${formatDate(a.dateTime)} الساعة ${formatTime(a.dateTime)}'
          '${a.place.isEmpty ? '' : '\nالمكان: ${a.place}'}';

      final remindAt = a.dateTime.subtract(Duration(minutes: a.remindBefore));
      await _zoned(
        title: 'ميعاد طبي 🏥: $title',
        body: details,
        when: remindAt,
        channel: _chAppts,
        mode: mode,
      );

      // تذكير في الليلة السابقة الساعة 8 مساءً.
      final eve = DateTime(a.dateTime.year, a.dateTime.month, a.dateTime.day - 1, 20, 0);
      if (eve.isBefore(remindAt)) {
        await _zoned(
          title: 'غدًا ميعاد طبي 🏥: $title',
          body: details,
          when: eve,
          channel: _chAppts,
          mode: mode,
        );
      }
    }
  }

  Future<void> _scheduleAssociations(
      List<Association> associations, AndroidScheduleMode mode) async {
    for (final a in associations) {
      if (a.isCompleted) continue;
      final owner = a.ownerLabel;

      var scheduled = 0;
      for (var month = 1; month <= a.totalMonths && scheduled < 6; month++) {
        if (a.paidMonths.contains(month)) continue;
        final due = a.dueDateOf(month);
        final dayStart = DateTime(due.year, due.month, due.day, 9, 0);
        final body =
            '$owner - قسط شهر $month: ${formatMoney(a.monthlyAmount)}';
        await _zoned(
          title: 'موعد دفع جمعية "${a.name}" 💰',
          body: body,
          when: dayStart,
          channel: _chAssoc,
          mode: mode,
        );
        await _zoned(
          title: 'غدًا موعد دفع جمعية "${a.name}" 💰',
          body: body,
          when: DateTime(due.year, due.month, due.day - 1, 9, 0),
          channel: _chAssoc,
          mode: mode,
        );
        scheduled++;
      }

      final collect = a.collectDate;
      await _zoned(
        title: 'اليوم موعد قبض جمعية "${a.name}" 🎉',
        body: '$owner - المبلغ: ${formatMoney(a.totalAmount)}',
        when: DateTime(collect.year, collect.month, collect.day, 9, 0),
        channel: _chAssoc,
        mode: mode,
      );
    }
  }
}
