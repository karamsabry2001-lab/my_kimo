import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../db/database_helper.dart';
import '../models/appointment.dart';
import '../models/association.dart';
import '../models/document_item.dart';
import '../models/medicine.dart';
import '../services/file_service.dart';
import '../services/notification_service.dart';

class NextDose {
  final Medicine medicine;
  final DateTime time;
  NextDose(this.medicine, this.time);
}

/// الحالة العامة للتطبيق: البيانات + الإعدادات.
class AppState extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;

  List<Association> associations = [];
  List<Appointment> appointments = [];
  List<Medicine> medicines = [];
  List<DocumentItem> documents = [];

  ThemeMode themeMode = ThemeMode.system;
  bool notifMeds = true;
  bool notifAppts = true;
  bool notifAssoc = true;
  bool loaded = false;

  Future<void> _scheduleChain = Future.value();

  // ------------------------------------------------------------- التحميل

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final t = prefs.getString('theme_mode') ?? 'system';
    themeMode = ThemeMode.values
        .firstWhere((e) => e.name == t, orElse: () => ThemeMode.system);
    notifMeds = prefs.getBool('notif_meds') ?? true;
    notifAppts = prefs.getBool('notif_appts') ?? true;
    notifAssoc = prefs.getBool('notif_assoc') ?? true;

    await _reloadData();
    loaded = true;
    notifyListeners();
    unawaited(_reschedule());
  }

  Future<void> _reloadData() async {
    associations = await _db.getAssociations();
    appointments = await _db.getAppointments();
    medicines = await _db.getMedicines();
    documents = await _db.getDocuments();
  }

  Future<void> _afterChange() async {
    await _reloadData();
    notifyListeners();
    unawaited(_reschedule());
  }

  /// تنفيذ إعادة الجدولة بالتسلسل لتفادي التداخل.
  Future<void> _reschedule() {
    _scheduleChain = _scheduleChain.then((_) async {
      try {
        await NotificationService.instance.rescheduleAll(
          medicines: medicines,
          appointments: appointments,
          associations: associations,
          meds: notifMeds,
          appts: notifAppts,
          assoc: notifAssoc,
        );
      } catch (e) {
        debugPrint('Reschedule failed: $e');
      }
    });
    return _scheduleChain;
  }

  Future<void> reloadAfterImport() => _afterChange();

  // ------------------------------------------------------------ الإعدادات

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', mode.name);
  }

  Future<void> setNotifMeds(bool v) async {
    notifMeds = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notif_meds', v);
    unawaited(_reschedule());
  }

  Future<void> setNotifAppts(bool v) async {
    notifAppts = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notif_appts', v);
    unawaited(_reschedule());
  }

  Future<void> setNotifAssoc(bool v) async {
    notifAssoc = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notif_assoc', v);
    unawaited(_reschedule());
  }

  Future<void> rescheduleNow() => _reschedule();

  // -------------------------------------------------------------- الجمعيات

  Association? associationById(int id) {
    for (final a in associations) {
      if (a.id == id) return a;
    }
    return null;
  }

  List<Association> associationsOf(String owner) =>
      associations.where((a) => a.owner == owner).toList();

  Future<void> saveAssociation(Association a) async {
    if (a.id == null) {
      await _db.insertAssociation(a);
    } else {
      await _db.updateAssociation(a);
    }
    await _afterChange();
  }

  Future<void> deleteAssociation(int id) async {
    await _db.deleteAssociation(id);
    await _afterChange();
  }

  Future<void> toggleAssociationPaid(Association a, int month) async {
    final paid = List<int>.from(a.paidMonths);
    if (paid.contains(month)) {
      paid.remove(month);
    } else {
      paid.add(month);
    }
    paid.sort();
    a.paidMonths = paid;
    await _db.updateAssociation(a);
    await _afterChange();
  }

  // --------------------------------------------------------------- المواعيد

  Future<void> saveAppointment(Appointment a) async {
    if (a.id == null) {
      await _db.insertAppointment(a);
    } else {
      await _db.updateAppointment(a);
    }
    await _afterChange();
  }

  Future<void> deleteAppointment(int id) async {
    await _db.deleteAppointment(id);
    await _afterChange();
  }

  Future<void> setAppointmentDone(Appointment a, bool done) async {
    a.done = done;
    await _db.updateAppointment(a);
    await _afterChange();
  }

  // ---------------------------------------------------------------- الأدوية

  Future<void> saveMedicine(Medicine m) async {
    if (m.id == null) {
      await _db.insertMedicine(m);
    } else {
      await _db.updateMedicine(m);
    }
    await _afterChange();
  }

  Future<void> deleteMedicine(int id) async {
    await _db.deleteMedicine(id);
    await _afterChange();
  }

  Future<void> setMedicineActive(Medicine m, bool active) async {
    m.active = active;
    await _db.updateMedicine(m);
    await _afterChange();
  }

  /// تسجيل أخذ جرعة: خصم عدد الأقراص من المخزون.
  Future<void> takeDose(Medicine m) async {
    if (m.pillsRemaining == null) return;
    final left = m.pillsRemaining! - m.pillsPerDose;
    m.pillsRemaining = left < 0 ? 0 : left;
    await _db.updateMedicine(m);
    await _afterChange();
  }

  Future<void> refillMedicine(Medicine m, int count) async {
    m.pillsRemaining = (m.pillsRemaining ?? 0) + count;
    await _db.updateMedicine(m);
    await _afterChange();
  }

  // -------------------------------------------------------------- المستندات

  Future<void> saveDocument(DocumentItem d) async {
    if (d.id == null) {
      await _db.insertDocument(d);
    } else {
      await _db.updateDocument(d);
    }
    await _afterChange();
  }

  Future<void> deleteDocument(DocumentItem d) async {
    if (d.id != null) await _db.deleteDocument(d.id!);
    await FileService.delete(d.fileName);
    await _afterChange();
  }

  // ------------------------------------------------------ بيانات الرئيسية

  NextDose? get nextDose {
    final now = DateTime.now();
    NextDose? best;
    for (final m in medicines) {
      if (!m.isActive) continue;
      final t = m.nextDoseAfter(now);
      if (t == null) continue;
      if (best == null || t.isBefore(best.time)) best = NextDose(m, t);
    }
    return best;
  }

  Appointment? get nextAppointment {
    final now = DateTime.now();
    Appointment? best;
    for (final a in appointments) {
      if (a.done || !a.dateTime.isAfter(now)) continue;
      if (best == null || a.dateTime.isBefore(best.dateTime)) best = a;
    }
    return best;
  }

  List<Medicine> get lowStockMedicines =>
      medicines.where((m) => m.needsRefill).toList();
}
