import '../utils/helpers.dart';

/// جمعية شهرية: يدفع صاحبها قسطاً ثابتاً كل شهر ويقبض المبلغ الكامل في دوره.
class Association {
  static const String ownerMe = 'me';
  static const String ownerMother = 'mother';

  int? id;
  String owner; // me | mother
  String name;
  double monthlyAmount;
  int totalMonths;
  DateTime startDate; // تاريخ القسط الأول
  int collectMonth; // رقم الشهر الذي يتم فيه القبض (1..totalMonths)
  String notes;
  List<int> paidMonths; // أرقام الأشهر المدفوعة

  Association({
    this.id,
    required this.owner,
    required this.name,
    required this.monthlyAmount,
    required this.totalMonths,
    required this.startDate,
    required this.collectMonth,
    this.notes = '',
    List<int>? paidMonths,
  }) : paidMonths = paidMonths ?? [];

  String get ownerLabel => owner == ownerMother ? 'حساب الوالدة' : 'حسابي';

  DateTime dueDateOf(int month) => addMonths(startDate, month - 1);

  DateTime get collectDate => dueDateOf(collectMonth);

  double get totalAmount => monthlyAmount * totalMonths;

  int get paidCount =>
      paidMonths.where((m) => m >= 1 && m <= totalMonths).toSet().length;

  double get paidAmount => monthlyAmount * paidCount;

  double get remainingAmount => totalAmount - paidAmount;

  bool get isCompleted => paidCount >= totalMonths;

  int? get nextUnpaidMonth {
    for (var i = 1; i <= totalMonths; i++) {
      if (!paidMonths.contains(i)) return i;
    }
    return null;
  }

  DateTime? get nextDueDate {
    final n = nextUnpaidMonth;
    return n == null ? null : dueDateOf(n);
  }

  bool get collectDatePassed =>
      daysBetween(DateTime.now(), collectDate) < 0;

  Map<String, Object?> toMap() => {
        'id': id,
        'owner': owner,
        'name': name,
        'monthly_amount': monthlyAmount,
        'total_months': totalMonths,
        'start_date': startDate.toIso8601String(),
        'collect_month': collectMonth,
        'notes': notes,
        'paid_months': paidMonths.join(','),
      };

  factory Association.fromMap(Map<String, Object?> m) => Association(
        id: m['id'] as int?,
        owner: (m['owner'] as String?) ?? ownerMe,
        name: (m['name'] as String?) ?? '',
        monthlyAmount: ((m['monthly_amount'] as num?) ?? 0).toDouble(),
        totalMonths: (m['total_months'] as int?) ?? 1,
        startDate: DateTime.parse(m['start_date'] as String),
        collectMonth: (m['collect_month'] as int?) ?? 1,
        notes: (m['notes'] as String?) ?? '',
        paidMonths: parseIntList(m['paid_months'] as String?),
      );
}
