/// تصنيفات المستندات الطبية.
const Map<String, String> kDocCategories = {
  'prescription': 'روشتة',
  'report': 'تقرير طبي',
  'test': 'تحليل / أشعة',
  'other': 'أخرى',
};

/// مستند طبي مؤرشف (روشتة، تقرير، تحليل...). الملف نفسه محفوظ داخل مجلد التطبيق.
class DocumentItem {
  int? id;
  String title;
  String category;
  String fileName; // اسم الملف داخل مجلد المرفقات
  String originalName;
  DateTime date;
  String notes;

  DocumentItem({
    this.id,
    required this.title,
    this.category = 'prescription',
    required this.fileName,
    this.originalName = '',
    required this.date,
    this.notes = '',
  });

  String get categoryLabel => kDocCategories[category] ?? 'أخرى';

  String get extension {
    final i = fileName.lastIndexOf('.');
    return i < 0 ? '' : fileName.substring(i + 1).toLowerCase();
  }

  bool get isImage =>
      const ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'heic'].contains(extension);

  bool get isPdf => extension == 'pdf';

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'category': category,
        'file_name': fileName,
        'original_name': originalName,
        'date': date.toIso8601String(),
        'notes': notes,
      };

  factory DocumentItem.fromMap(Map<String, Object?> m) => DocumentItem(
        id: m['id'] as int?,
        title: (m['title'] as String?) ?? '',
        category: (m['category'] as String?) ?? 'other',
        fileName: (m['file_name'] as String?) ?? '',
        originalName: (m['original_name'] as String?) ?? '',
        date: DateTime.parse(m['date'] as String),
        notes: (m['notes'] as String?) ?? '',
      );
}
