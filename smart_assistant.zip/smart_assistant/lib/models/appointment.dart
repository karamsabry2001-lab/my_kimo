/// ميعاد في مستشفى / عيادة.
class Appointment {
  int? id;
  String title; // التخصص أو سبب الزيارة (اختياري)
  String doctor;
  String place;
  DateTime dateTime;
  String notes;
  int remindBefore; // بالدقائق
  bool done;

  Appointment({
    this.id,
    this.title = '',
    required this.doctor,
    this.place = '',
    required this.dateTime,
    this.notes = '',
    this.remindBefore = 60,
    this.done = false,
  });

  bool get isPast => dateTime.isBefore(DateTime.now());

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'doctor': doctor,
        'place': place,
        'date_time': dateTime.toIso8601String(),
        'notes': notes,
        'remind_before': remindBefore,
        'done': done ? 1 : 0,
      };

  factory Appointment.fromMap(Map<String, Object?> m) => Appointment(
        id: m['id'] as int?,
        title: (m['title'] as String?) ?? '',
        doctor: (m['doctor'] as String?) ?? '',
        place: (m['place'] as String?) ?? '',
        dateTime: DateTime.parse(m['date_time'] as String),
        notes: (m['notes'] as String?) ?? '',
        remindBefore: (m['remind_before'] as int?) ?? 60,
        done: ((m['done'] as int?) ?? 0) == 1,
      );
}
