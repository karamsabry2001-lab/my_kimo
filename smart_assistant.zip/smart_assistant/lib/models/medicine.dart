import 'package:flutter/material.dart';

import '../utils/helpers.dart';

/// دواء مع جرعاته ومواعيده ومخزون العلبة.
class Medicine {
  int? id;
  String name;
  String dose; // وصف الجرعة مثل: "قرص واحد بعد الأكل"
  int pillsPerDose; // عدد الأقراص/الوحدات في الجرعة الواحدة (لخصم المخزون)
  int durationDays; // 0 = مستمر بدون نهاية
  DateTime startDate;
  List<String> times; // "HH:mm"
  List<int> weekdays; // فارغة = كل يوم، وإلا أرقام الأيام (الاثنين=1 ... الأحد=7)
  String notes;
  bool active;
  int? pillsRemaining; // null = بدون تتبع للمخزون
  int lowStockThreshold;

  Medicine({
    this.id,
    required this.name,
    this.dose = '',
    this.pillsPerDose = 1,
    this.durationDays = 0,
    required this.startDate,
    List<String>? times,
    List<int>? weekdays,
    this.notes = '',
    this.active = true,
    this.pillsRemaining,
    this.lowStockThreshold = 5,
  })  : times = times ?? [],
        weekdays = weekdays ?? [];

  List<TimeOfDay> get timeList {
    final list = times.map(parseHm).toList();
    list.sort((a, b) => hmMinutes(a) - hmMinutes(b));
    return list;
  }

  DateTime? get endDate => durationDays > 0
      ? DateTime(startDate.year, startDate.month, startDate.day + durationDays - 1)
      : null;

  bool get isExpired {
    final end = endDate;
    if (end == null) return false;
    return daysBetween(end, DateTime.now()) > 0;
  }

  /// نشط فعلياً: مفعّل ولم تنتهِ مدته.
  bool get isActive => active && !isExpired;

  bool get isLowStock =>
      pillsRemaining != null && pillsRemaining! <= lowStockThreshold;

  bool get needsRefill => isActive && isLowStock;

  /// عدد الأقراص المستهلكة يومياً (تقريبي).
  double? get pillsPerDay {
    if (times.isEmpty) return null;
    final factor = weekdays.isEmpty ? 1.0 : weekdays.length / 7.0;
    return times.length * factor * pillsPerDose;
  }

  int? get stockDaysLeft {
    if (pillsRemaining == null) return null;
    final ppd = pillsPerDay;
    if (ppd == null || ppd <= 0) return null;
    return (pillsRemaining! / ppd).floor();
  }

  String get daysLabel {
    if (weekdays.isEmpty) return 'كل يوم';
    final ordered =
        kWeekdayDisplayOrder.where((d) => weekdays.contains(d)).toList();
    return ordered.map(weekdayName).join('، ');
  }

  String get durationLabel {
    if (durationDays <= 0) {
      return 'المدة: مستمر (يبدأ ${formatDate(startDate)})';
    }
    return 'المدة: $durationDays يوم (من ${formatDate(startDate)} إلى ${formatDate(endDate!)})';
  }

  /// أقرب جرعة بعد الوقت [from] (أو null لو لا توجد).
  DateTime? nextDoseAfter(DateTime from) {
    if (!active || times.isEmpty) return null;
    final sorted = timeList;
    var day = dateOnly(from);
    final start = dateOnly(startDate);
    if (day.isBefore(start)) day = start;
    final end = endDate;
    for (var i = 0; i < 8; i++) {
      final d = DateTime(day.year, day.month, day.day + i);
      if (end != null && daysBetween(end, d) > 0) return null;
      if (weekdays.isNotEmpty && !weekdays.contains(d.weekday)) continue;
      for (final t in sorted) {
        final dt = DateTime(d.year, d.month, d.day, t.hour, t.minute);
        if (dt.isAfter(from)) return dt;
      }
    }
    return null;
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'dose': dose,
        'pills_per_dose': pillsPerDose,
        'duration_days': durationDays,
        'start_date': startDate.toIso8601String(),
        'times': times.join(','),
        'weekdays': weekdays.join(','),
        'notes': notes,
        'active': active ? 1 : 0,
        'pills_remaining': pillsRemaining,
        'low_stock_threshold': lowStockThreshold,
      };

  factory Medicine.fromMap(Map<String, Object?> m) => Medicine(
        id: m['id'] as int?,
        name: (m['name'] as String?) ?? '',
        dose: (m['dose'] as String?) ?? '',
        pillsPerDose: (m['pills_per_dose'] as int?) ?? 1,
        durationDays: (m['duration_days'] as int?) ?? 0,
        startDate: DateTime.parse(m['start_date'] as String),
        times: ((m['times'] as String?) ?? '')
            .split(',')
            .where((e) => e.trim().isNotEmpty)
            .toList(),
        weekdays: parseIntList(m['weekdays'] as String?),
        notes: (m['notes'] as String?) ?? '',
        active: ((m['active'] as int?) ?? 1) == 1,
        pillsRemaining: m['pills_remaining'] as int?,
        lowStockThreshold: (m['low_stock_threshold'] as int?) ?? 5,
      );
}
