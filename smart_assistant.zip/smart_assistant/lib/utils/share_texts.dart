import '../models/appointment.dart';
import '../models/association.dart';
import '../models/medicine.dart';
import 'helpers.dart';

String appointmentShareText(Appointment a) {
  final b = StringBuffer('📅 ميعاد طبي\n');
  if (a.title.isNotEmpty) b.writeln('التخصص/السبب: ${a.title}');
  b.writeln('الطبيب: ${a.doctor}');
  if (a.place.isNotEmpty) b.writeln('المكان: ${a.place}');
  b.writeln('اليوم: ${weekdayName(a.dateTime.weekday)}');
  b.writeln('التاريخ: ${formatDate(a.dateTime)}');
  b.writeln('الساعة: ${formatTime(a.dateTime)}');
  if (a.notes.isNotEmpty) b.writeln('ملاحظات: ${a.notes}');
  return b.toString().trim();
}

String appointmentsSummaryText(List<Appointment> list) {
  if (list.isEmpty) return 'لا توجد مواعيد قادمة.';
  final b = StringBuffer('📅 مواعيدي الطبية القادمة\n\n');
  for (var i = 0; i < list.length; i++) {
    final a = list[i];
    b.writeln('${i + 1}) ${a.doctor}${a.title.isEmpty ? '' : ' (${a.title})'}');
    b.writeln('   ${formatDateWithDay(a.dateTime)} - ${formatTime(a.dateTime)}');
    if (a.place.isNotEmpty) b.writeln('   المكان: ${a.place}');
    b.writeln();
  }
  return b.toString().trim();
}

String medicineShareText(Medicine m) {
  final b = StringBuffer('💊 دواء: ${m.name}\n');
  if (m.dose.isNotEmpty) b.writeln('الجرعة: ${m.dose}');
  b.writeln('المواعيد: ${m.timeList.map(formatTimeOfDay).join('، ')}');
  b.writeln('الأيام: ${m.daysLabel}');
  b.writeln(m.durationLabel);
  b.writeln('الحالة: ${m.isActive ? 'نشط' : 'منتهي'}');
  if (m.pillsRemaining != null) b.writeln('المتبقي في العلبة: ${m.pillsRemaining}');
  if (m.notes.isNotEmpty) b.writeln('ملاحظات: ${m.notes}');
  return b.toString().trim();
}

String medicinesSummaryText(List<Medicine> list) {
  if (list.isEmpty) return 'لا توجد أدوية نشطة.';
  final b = StringBuffer('💊 جدول الأدوية\n\n');
  for (var i = 0; i < list.length; i++) {
    final m = list[i];
    b.writeln('${i + 1}) ${m.name}${m.dose.isEmpty ? '' : ' - ${m.dose}'}');
    b.writeln('   المواعيد: ${m.timeList.map(formatTimeOfDay).join('، ')} (${m.daysLabel})');
    if (m.notes.isNotEmpty) b.writeln('   ملاحظات: ${m.notes}');
    b.writeln();
  }
  return b.toString().trim();
}

String associationShareText(Association a) {
  final b = StringBuffer('💰 جمعية: ${a.name} (${a.ownerLabel})\n');
  b.writeln('القسط الشهري: ${formatMoney(a.monthlyAmount)}');
  b.writeln('عدد الأشهر: ${a.totalMonths}');
  b.writeln('أول قسط: ${formatDate(a.startDate)}');
  b.writeln('دور القبض: الشهر ${a.collectMonth} (${formatDate(a.collectDate)})');
  b.writeln('مبلغ القبض: ${formatMoney(a.totalAmount)}');
  b.writeln('المدفوع: ${a.paidCount} من ${a.totalMonths} (${formatMoney(a.paidAmount)})');
  b.writeln('المتبقي: ${formatMoney(a.remainingAmount)}');
  final next = a.nextDueDate;
  if (next != null) b.writeln('القسط القادم: ${formatDate(next)}');
  if (a.notes.isNotEmpty) b.writeln('ملاحظات: ${a.notes}');
  return b.toString().trim();
}
