import 'package:flutter/material.dart';

/// رمز العملة المستخدم في كل التطبيق (يمكن تغييره هنا).
const String kCurrency = 'ج.م';

const List<String> kMonthNames = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/// الترتيب حسب DateTime.weekday: الاثنين = 1 ... الأحد = 7
const List<String> kWeekdayNames = [
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
  'الأحد',
];

/// ترتيب عرض الأيام (الأسبوع يبدأ من السبت)
const List<int> kWeekdayDisplayOrder = [6, 7, 1, 2, 3, 4, 5];

String weekdayName(int weekday) => kWeekdayNames[(weekday - 1) % 7];

String two(int n) => n.toString().padLeft(2, '0');

/// تحويل الأرقام العربية/الفارسية إلى أرقام إنجليزية.
String normalizeDigits(String input) {
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  final sb = StringBuffer();
  for (final ch in input.split('')) {
    final a = arabic.indexOf(ch);
    final p = persian.indexOf(ch);
    if (a >= 0) {
      sb.write(a);
    } else if (p >= 0) {
      sb.write(p);
    } else {
      sb.write(ch);
    }
  }
  return sb.toString();
}

double? parseDouble(String? s) {
  if (s == null) return null;
  final t = normalizeDigits(s)
      .replaceAll('٫', '.')
      .replaceAll('،', '.')
      .replaceAll(',', '.')
      .trim();
  if (t.isEmpty) return null;
  return double.tryParse(t);
}

int? parseInt(String? s) {
  if (s == null) return null;
  final t = normalizeDigits(s).trim();
  if (t.isEmpty) return null;
  return int.tryParse(t);
}

List<int> parseIntList(String? s) {
  if (s == null || s.trim().isEmpty) return [];
  return s
      .split(',')
      .map((e) => int.tryParse(e.trim()))
      .whereType<int>()
      .toList();
}

// ---------------------------------------------------------------- التواريخ

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// عدد الأيام بين تاريخين (بدون تأثر بتغيير التوقيت الصيفي).
int daysBetween(DateTime from, DateTime to) {
  final a = DateTime.utc(from.year, from.month, from.day);
  final b = DateTime.utc(to.year, to.month, to.day);
  return b.difference(a).inDays;
}

/// إضافة أشهر مع الحفاظ على اليوم قدر الإمكان (31 يناير + شهر = 28/29 فبراير).
DateTime addMonths(DateTime d, int months) {
  final total = d.month - 1 + months;
  final year = d.year + total ~/ 12;
  final month = total % 12 + 1;
  final lastDay = DateTime(year, month + 1, 0).day;
  final day = d.day > lastDay ? lastDay : d.day;
  return DateTime(year, month, day, d.hour, d.minute);
}

String formatDate(DateTime d) => '${d.day} ${kMonthNames[d.month - 1]} ${d.year}';

String formatDateWithDay(DateTime d) => '${weekdayName(d.weekday)} ${formatDate(d)}';

String formatHm(int hour, int minute) {
  final period = hour >= 12 ? 'م' : 'ص';
  final h12 = hour % 12 == 0 ? 12 : hour % 12;
  return '$h12:${two(minute)} $period';
}

String formatTime(DateTime d) => formatHm(d.hour, d.minute);

String formatTimeOfDay(TimeOfDay t) => formatHm(t.hour, t.minute);

TimeOfDay parseHm(String s) {
  final parts = s.split(':');
  return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
}

String hmToString(TimeOfDay t) => '${two(t.hour)}:${two(t.minute)}';

int hmMinutes(TimeOfDay t) => t.hour * 60 + t.minute;

/// نص نسبي مثل: "بعد 3 ساعة" أو "غدًا".
String relativeFromNow(DateTime t) {
  final diff = t.difference(DateTime.now());
  if (diff.isNegative) return 'الآن';
  if (diff.inMinutes < 1) return 'بعد لحظات';
  if (diff.inMinutes < 60) return 'بعد ${diff.inMinutes} دقيقة';
  if (diff.inHours < 24 && isSameDay(t, DateTime.now())) {
    return 'بعد ${diff.inHours} ساعة';
  }
  return dayDistanceText(t);
}

/// "اليوم" / "غدًا" / "بعد N يوم" / "منذ N يوم".
String dayDistanceText(DateTime date) {
  final days = daysBetween(DateTime.now(), date);
  if (days == 0) return 'اليوم';
  if (days == 1) return 'غدًا';
  if (days == 2) return 'بعد يومين';
  if (days > 2) return 'بعد $days يوم';
  if (days == -1) return 'أمس';
  return 'منذ ${-days} يوم';
}

// ------------------------------------------------------------------ الأرقام

String formatNumber(num v) {
  final isInt = v == v.roundToDouble();
  final s = isInt ? v.toInt().toString() : v.toStringAsFixed(2);
  final parts = s.split('.');
  final intPart = parts[0].replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (m) => ',',
  );
  return parts.length > 1 ? '$intPart.${parts[1]}' : intPart;
}

String formatMoney(num v) => '${formatNumber(v)} $kCurrency';
