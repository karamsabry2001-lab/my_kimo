import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/appointment.dart';
import '../models/association.dart';
import '../models/document_item.dart';
import '../models/medicine.dart';

/// طبقة قاعدة البيانات المحلية (SQLite) - تعمل بدون إنترنت.
class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  static const List<String> _tables = [
    'associations',
    'appointments',
    'medicines',
    'documents',
  ];

  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'smart_assistant.db');
    return openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE associations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner TEXT NOT NULL,
        name TEXT NOT NULL,
        monthly_amount REAL NOT NULL,
        total_months INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        collect_month INTEGER NOT NULL,
        notes TEXT,
        paid_months TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        doctor TEXT NOT NULL,
        place TEXT,
        date_time TEXT NOT NULL,
        notes TEXT,
        remind_before INTEGER NOT NULL DEFAULT 60,
        done INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE medicines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        dose TEXT,
        pills_per_dose INTEGER NOT NULL DEFAULT 1,
        duration_days INTEGER NOT NULL DEFAULT 0,
        start_date TEXT NOT NULL,
        times TEXT,
        weekdays TEXT,
        notes TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        pills_remaining INTEGER,
        low_stock_threshold INTEGER NOT NULL DEFAULT 5
      )
    ''');
    await db.execute('''
      CREATE TABLE documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        file_name TEXT NOT NULL,
        original_name TEXT,
        date TEXT NOT NULL,
        notes TEXT
      )
    ''');
  }

  // ------------------------------------------------------------- الجمعيات

  Future<List<Association>> getAssociations() async {
    final db = await database;
    final rows = await db.query('associations', orderBy: 'id DESC');
    return rows.map(Association.fromMap).toList();
  }

  Future<int> insertAssociation(Association a) async =>
      (await database).insert('associations', a.toMap());

  Future<int> updateAssociation(Association a) async => (await database)
      .update('associations', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<int> deleteAssociation(int id) async => (await database)
      .delete('associations', where: 'id = ?', whereArgs: [id]);

  // -------------------------------------------------------------- المواعيد

  Future<List<Appointment>> getAppointments() async {
    final db = await database;
    final rows = await db.query('appointments', orderBy: 'date_time ASC');
    return rows.map(Appointment.fromMap).toList();
  }

  Future<int> insertAppointment(Appointment a) async =>
      (await database).insert('appointments', a.toMap());

  Future<int> updateAppointment(Appointment a) async => (await database)
      .update('appointments', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<int> deleteAppointment(int id) async => (await database)
      .delete('appointments', where: 'id = ?', whereArgs: [id]);

  // --------------------------------------------------------------- الأدوية

  Future<List<Medicine>> getMedicines() async {
    final db = await database;
    final rows = await db.query('medicines', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map(Medicine.fromMap).toList();
  }

  Future<int> insertMedicine(Medicine m) async =>
      (await database).insert('medicines', m.toMap());

  Future<int> updateMedicine(Medicine m) async => (await database)
      .update('medicines', m.toMap(), where: 'id = ?', whereArgs: [m.id]);

  Future<int> deleteMedicine(int id) async =>
      (await database).delete('medicines', where: 'id = ?', whereArgs: [id]);

  // -------------------------------------------------------------- المستندات

  Future<List<DocumentItem>> getDocuments() async {
    final db = await database;
    final rows = await db.query('documents', orderBy: 'date DESC, id DESC');
    return rows.map(DocumentItem.fromMap).toList();
  }

  Future<int> insertDocument(DocumentItem d) async =>
      (await database).insert('documents', d.toMap());

  Future<int> updateDocument(DocumentItem d) async => (await database)
      .update('documents', d.toMap(), where: 'id = ?', whereArgs: [d.id]);

  Future<int> deleteDocument(int id) async =>
      (await database).delete('documents', where: 'id = ?', whereArgs: [id]);

  // ------------------------------------------------- النسخ الاحتياطي/الاستيراد

  Future<Map<String, List<Map<String, Object?>>>> exportAll() async {
    final db = await database;
    final result = <String, List<Map<String, Object?>>>{};
    for (final t in _tables) {
      result[t] = await db.query(t);
    }
    return result;
  }

  /// استبدال كل البيانات الحالية بالبيانات المستوردة (داخل transaction واحد).
  Future<void> importAll(Map<String, dynamic> data) async {
    final db = await database;
    await db.transaction((txn) async {
      for (final t in _tables) {
        await txn.delete(t);
      }
      for (final t in _tables) {
        final rows = (data[t] as List?) ?? const [];
        for (final r in rows) {
          await txn.insert(
            t,
            Map<String, Object?>.from(r as Map),
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
    });
  }
}
