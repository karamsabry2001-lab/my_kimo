import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/document_item.dart';
import '../providers/app_state.dart';
import '../services/file_service.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// نموذج حفظ / تعديل بيانات مستند طبي.
/// عند الإضافة: يُمرَّر [pickedPath] (الملف الذي تم اختياره).
/// عند التعديل: يُمرَّر [existing].
class DocumentFormScreen extends StatefulWidget {
  final DocumentItem? existing;
  final String? pickedPath;
  final String? pickedName;

  const DocumentFormScreen({
    super.key,
    this.existing,
    this.pickedPath,
    this.pickedName,
  });

  @override
  State<DocumentFormScreen> createState() => _DocumentFormScreenState();
}

class _DocumentFormScreenState extends State<DocumentFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleC;
  late final TextEditingController _notesC;
  late String _category;
  late DateTime _date;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _category = e?.category ?? 'prescription';
    _date = e?.date ?? dateOnly(DateTime.now());
    _titleC = TextEditingController(
      text: e?.title ?? 'روشتة ${formatDate(_date)}',
    );
    _notesC = TextEditingController(text: e?.notes ?? '');
  }

  @override
  void dispose() {
    _titleC.dispose();
    _notesC.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final state = context.read<AppState>();
    final nav = Navigator.of(context);
    final e = widget.existing;
    setState(() => _saving = true);

    try {
      if (e != null) {
        e.title = _titleC.text.trim();
        e.category = _category;
        e.date = _date;
        e.notes = _notesC.text.trim();
        await state.saveDocument(e);
      } else {
        final stored = await FileService.importFile(widget.pickedPath!);
        await state.saveDocument(DocumentItem(
          title: _titleC.text.trim(),
          category: _category,
          fileName: stored,
          originalName: widget.pickedName ?? '',
          date: _date,
          notes: _notesC.text.trim(),
        ));
      }
      nav.pop();
    } catch (err) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, 'تعذر حفظ المستند');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'تعديل المستند' : 'حفظ في الأرشيف')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (!isEdit && widget.pickedName != null)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.attach_file),
                  title: Text(widget.pickedName!, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: const Text('الملف المرفق'),
                ),
              ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _titleC,
              decoration: fieldDecoration('عنوان المستند', icon: Icons.title),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'اكتب عنوانًا' : null,
            ),
            const SizedBox(height: 16),
            const Text('النوع'),
            const SizedBox(height: 4),
            ChoiceRow<String>(
              options: kDocCategories,
              value: _category,
              onChanged: (v) => setState(() => _category = v),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () async {
                final d = await pickDate(context, _date);
                if (d != null) setState(() => _date = d);
              },
              child: InputDecorator(
                decoration: fieldDecoration('تاريخ المستند', icon: Icons.event_outlined),
                child: Text(formatDateWithDay(_date)),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesC,
              maxLines: 3,
              decoration: fieldDecoration('ملاحظات (اختياري)', icon: Icons.notes),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
