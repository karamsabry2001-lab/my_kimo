import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/appointment.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../utils/share_texts.dart';
import '../widgets/common.dart';
import 'appointment_form_screen.dart';

/// قسم مواعيد المستشفيات.
class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  String _query = '';
  String _filter = 'upcoming';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final now = DateTime.now();
    final q = _query.trim();

    var list = state.appointments.where((a) {
      if (_filter == 'upcoming' && (a.done || a.dateTime.isBefore(now))) return false;
      if (_filter == 'past' && !(a.done || a.dateTime.isBefore(now))) return false;
      if (q.isNotEmpty &&
          !a.doctor.contains(q) &&
          !a.place.contains(q) &&
          !a.title.contains(q) &&
          !a.notes.contains(q)) {
        return false;
      }
      return true;
    }).toList();

    // القادمة تصاعدياً، والباقي تنازلياً.
    list.sort((x, y) => _filter == 'upcoming'
        ? x.dateTime.compareTo(y.dateTime)
        : y.dateTime.compareTo(x.dateTime));

    final upcoming = state.appointments
        .where((a) => !a.done && a.dateTime.isAfter(now))
        .toList()
      ..sort((x, y) => x.dateTime.compareTo(y.dateTime));

    return Scaffold(
      appBar: AppBar(
        title: const Text('مواعيد المستشفيات'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'مشاركة المواعيد القادمة',
            onPressed: () => Share.share(appointmentsSummaryText(upcoming)),
          ),
          const ThemeToggleButton(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const AppointmentFormScreen()),
        ),
        icon: const Icon(Icons.add),
        label: const Text('إضافة ميعاد'),
      ),
      body: Column(
        children: [
          AppSearchField(
            hint: 'ابحث بالطبيب أو المكان أو الملاحظات',
            onChanged: (v) => setState(() => _query = v),
          ),
          ChoiceRow<String>(
            options: const {'upcoming': 'القادمة', 'past': 'السابقة', 'all': 'الكل'},
            value: _filter,
            onChanged: (v) => setState(() => _filter = v),
          ),
          Expanded(
            child: state.appointments.isEmpty
                ? const EmptyState(
                    icon: Icons.local_hospital_outlined,
                    message: 'لا توجد مواعيد مسجلة.\nاضغط "إضافة ميعاد" للبدء.',
                  )
                : list.isEmpty
                    ? const EmptyState(
                        icon: Icons.search_off, message: 'لا توجد نتائج مطابقة')
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _AppointmentCard(appointment: list[i]),
                      ),
          ),
        ],
      ),
    );
  }
}

class _AppointmentCard extends StatelessWidget {
  final Appointment appointment;
  const _AppointmentCard({required this.appointment});

  @override
  Widget build(BuildContext context) {
    final a = appointment;
    final scheme = Theme.of(context).colorScheme;
    final overdue = !a.done && a.isPast;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // مربع التاريخ
            Container(
              width: 64,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: a.done ? scheme.surfaceContainerHighest : scheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Text(
                    '${a.dateTime.day}',
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  Text(kMonthNames[a.dateTime.month - 1],
                      style: const TextStyle(fontSize: 12)),
                  Text('${a.dateTime.year}', style: const TextStyle(fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          a.doctor,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      if (a.done)
                        const StatusChip(label: 'تم', color: Colors.green)
                      else if (overdue)
                        StatusChip(label: 'فات الميعاد', color: scheme.error),
                    ],
                  ),
                  if (a.title.isNotEmpty) Text(a.title),
                  InfoLine(
                    icon: Icons.event,
                    text:
                        '${weekdayName(a.dateTime.weekday)} - ${formatTime(a.dateTime)}',
                  ),
                  if (a.place.isNotEmpty)
                    InfoLine(icon: Icons.place_outlined, text: a.place),
                  if (a.notes.isNotEmpty)
                    InfoLine(icon: Icons.notes, text: a.notes),
                  if (!a.done && !overdue)
                    InfoLine(
                      icon: Icons.hourglass_bottom,
                      text: relativeFromNow(a.dateTime),
                    ),
                ],
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (v) => _onMenu(context, v),
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'done',
                  child: Text(a.done ? 'إلغاء علامة "تم"' : 'تم الذهاب'),
                ),
                const PopupMenuItem(value: 'edit', child: Text('تعديل')),
                const PopupMenuItem(value: 'share', child: Text('مشاركة')),
                const PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _onMenu(BuildContext context, String value) async {
    final a = appointment;
    final state = context.read<AppState>();
    switch (value) {
      case 'done':
        await state.setAppointmentDone(a, !a.done);
        break;
      case 'edit':
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => AppointmentFormScreen(existing: a)),
        );
        break;
      case 'share':
        Share.share(appointmentShareText(a));
        break;
      case 'delete':
        final ok = await confirmDialog(
          context,
          title: 'حذف الميعاد',
          message: 'هل تريد حذف ميعاد "${a.doctor}"؟',
        );
        if (ok && a.id != null) await state.deleteAppointment(a.id!);
        break;
    }
  }
}
