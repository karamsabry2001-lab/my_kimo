import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../services/backup_service.dart';
import '../services/notification_service.dart';
import '../widgets/common.dart';

/// الإعدادات: المظهر، التنبيهات، النسخ الاحتياطي.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      if (mounted) showSnack(context, 'حدث خطأ: ${e is FormatException ? e.message : e}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final header = Theme.of(context)
        .textTheme
        .titleSmall
        ?.copyWith(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold);

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_busy) const LinearProgressIndicator(),
          Text('المظهر', style: header),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(
                  value: ThemeMode.light,
                  label: Text('نهاري'),
                  icon: Icon(Icons.light_mode_outlined)),
              ButtonSegment(
                  value: ThemeMode.dark,
                  label: Text('ليلي'),
                  icon: Icon(Icons.dark_mode_outlined)),
              ButtonSegment(
                  value: ThemeMode.system,
                  label: Text('تلقائي'),
                  icon: Icon(Icons.brightness_auto_outlined)),
            ],
            selected: {state.themeMode},
            onSelectionChanged: (s) => state.setThemeMode(s.first),
          ),
          const SizedBox(height: 24),
          Text('التنبيهات', style: header),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تنبيهات الأدوية'),
            subtitle: const Text('جرعات الأدوية واقتراب نفاد العلبة'),
            value: state.notifMeds,
            onChanged: state.setNotifMeds,
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تنبيهات المواعيد'),
            subtitle: const Text('مواعيد المستشفيات والعيادات'),
            value: state.notifAppts,
            onChanged: state.setNotifAppts,
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تنبيهات الجمعيات'),
            subtitle: const Text('مواعيد دفع الأقساط وقبض الجمعية'),
            value: state.notifAssoc,
            onChanged: state.setNotifAssoc,
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: () async {
                  await NotificationService.instance.requestPermissions();
                  await NotificationService.instance.showTest();
                },
                icon: const Icon(Icons.notifications_active_outlined),
                label: const Text('تنبيه تجريبي'),
              ),
              OutlinedButton.icon(
                onPressed: () async {
                  await NotificationService.instance.requestExactAlarms();
                  await state.rescheduleNow();
                },
                icon: const Icon(Icons.alarm_on_outlined),
                label: const Text('السماح بالتنبيهات الدقيقة'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'ملاحظة: على بعض الهواتف (شاومي، أوبو، سامسونج...) يجب السماح للتطبيق '
            'بالعمل في الخلفية وإيقاف توفير البطارية له حتى تصل التنبيهات في وقتها.',
            style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 24),
          Text('النسخ الاحتياطي (محلي)', style: header),
          const SizedBox(height: 8),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.save_alt),
            title: const Text('حفظ نسخة احتياطية'),
            subtitle: const Text('يحفظ البيانات والمرفقات في ملف ZIP تختار مكانه'),
            enabled: !_busy,
            onTap: () => _run(() async {
              final ok = await BackupService.saveBackupToDevice();
              if (mounted && ok) showSnack(context, 'تم حفظ النسخة الاحتياطية');
            }),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.ios_share),
            title: const Text('مشاركة نسخة احتياطية'),
            subtitle: const Text('أرسلها لنفسك عبر واتساب أو درايف أو بلوتوث'),
            enabled: !_busy,
            onTap: () => _run(() => BackupService.shareBackup()),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.restore),
            title: const Text('استيراد نسخة احتياطية'),
            subtitle: const Text('يستبدل كل البيانات الحالية بالنسخة المختارة'),
            enabled: !_busy,
            onTap: () async {
              final ok = await confirmDialog(
                context,
                title: 'استيراد نسخة احتياطية',
                message:
                    'سيتم استبدال كل البيانات والمرفقات الحالية بمحتوى النسخة. هل تريد المتابعة؟',
                confirmText: 'متابعة',
              );
              if (!ok) return;
              await _run(() async {
                final done = await BackupService.importBackup();
                if (done) {
                  await state.reloadAfterImport();
                  if (mounted) showSnack(context, 'تم استيراد البيانات بنجاح');
                }
              });
            },
          ),
          const SizedBox(height: 24),
          Text('عن التطبيق', style: header),
          const SizedBox(height: 8),
          const Text(
            'مساعدي الشخصي\nكل بياناتك محفوظة على هاتفك فقط، ولا يحتاج التطبيق إلى إنترنت.',
          ),
        ],
      ),
    );
  }
}
