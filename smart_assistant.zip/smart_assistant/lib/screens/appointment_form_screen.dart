import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/appointment.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// نموذج إضافة / تعديل ميعاد في مستشفى.
class AppointmentFormScreen extends StatefulWidget {
  final Appointment? existing;

  const AppointmentFormScreen({super.key, this.existing});

  @override
  State<AppointmentFormScreen> createState() => _AppointmentFormScreenState();
}

class _AppointmentFormScreenState extends State<AppointmentFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleC;
  late final TextEditingController _doctorC;
  late final TextEditingController _placeC;
  late final TextEditingController _notesC;
  late DateTime _date;
  late TimeOfDay _time;
  late int _remind;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _titleC = TextEditingController(text: e?.title ?? '');
    _doctorC = TextEditingController(text: e?.doctor ?? '');
    _placeC = TextEditingController(text: e?.place ?? '');
    _notesC = TextEditingController(text: e?.notes ?? '');
    if (e != null) {
      _date = dateOnly(e.dateTime);
      _time = TimeOfDay.fromDateTime(e.dateTime);
      _remind = e.remindBefore;
    } else {
      final tomorrow = DateTime.now().add(const Duration(days: 1));
      _date = dateOnly(tomorrow);
      _time = const TimeOfDay(hour: 10, minute: 0);
      _remind = 60;
    }
  }

  @override
  void dispose() {
    _titleC.dispose();
    _doctorC.dispose();
    _placeC.dispose();
    _notesC.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final state = context.read<AppState>();
    final nav = Navigator.of(context);
    final e = widget.existing;
    final a = Appointment(
      id: e?.id,
      title: _titleC.text.trim(),
      doctor: _doctorC.text.trim(),
      place: _placeC.text.trim(),
      dateTime: DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute),
      notes: _notesC.text.trim(),
      remindBefore: _remind,
      done: e?.done ?? false,
    );
    setState(() => _saving = true);
    await state.saveAppointment(a);
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'تعديل الميعاد' : 'إضافة ميعاد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _doctorC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('اسم الطبيب', icon: Icons.person_outline),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'اكتب اسم الطبيب' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _titleC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('التخصص / سبب الزيارة (اختياري)',
                  icon: Icons.medical_services_outlined),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _placeC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('المكان (مستشفى / عيادة)',
                  icon: Icons.place_outlined),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () async {
                final d = await pickDate(context, _date);
                if (d != null) setState(() => _date = d);
              },
              child: InputDecorator(
                decoration: fieldDecoration('التاريخ', icon: Icons.event_outlined),
                child: Text(formatDateWithDay(_date)),
              ),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () async {
                final t = await pickTime(context, _time);
                if (t != null) setState(() => _time = t);
              },
              child: InputDecorator(
                decoration: fieldDecoration('الساعة', icon: Icons.access_time),
                child: Text(formatTimeOfDay(_time)),
              ),
            ),
            const SizedBox(height: 16),
            const Text('التنبيه قبل الميعاد بـ'),
            const SizedBox(height: 4),
            ChoiceRow<int>(
              options: const {
                30: '30 دقيقة',
                60: 'ساعة',
                180: '3 ساعات',
                1440: 'يوم',
              },
              value: _remind,
              onChanged: (v) => setState(() => _remind = v),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesC,
              maxLines: 3,
              decoration: fieldDecoration('ملاحظات (اختياري)', icon: Icons.notes),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
