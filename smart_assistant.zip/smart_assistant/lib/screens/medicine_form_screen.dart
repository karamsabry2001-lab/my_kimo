import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/medicine.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// نموذج إضافة / تعديل دواء.
class MedicineFormScreen extends StatefulWidget {
  final Medicine? existing;

  const MedicineFormScreen({super.key, this.existing});

  @override
  State<MedicineFormScreen> createState() => _MedicineFormScreenState();
}

class _MedicineFormScreenState extends State<MedicineFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameC;
  late final TextEditingController _doseC;
  late final TextEditingController _perDoseC;
  late final TextEditingController _durationC;
  late final TextEditingController _stockC;
  late final TextEditingController _thresholdC;
  late final TextEditingController _notesC;
  late DateTime _start;
  late List<TimeOfDay> _times;
  late Set<int> _weekdays; // فارغة = كل يوم
  late bool _active;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameC = TextEditingController(text: e?.name ?? '');
    _doseC = TextEditingController(text: e?.dose ?? '');
    _perDoseC = TextEditingController(text: '${e?.pillsPerDose ?? 1}');
    _durationC = TextEditingController(text: '${e?.durationDays ?? 0}');
    _stockC = TextEditingController(
        text: e?.pillsRemaining == null ? '' : '${e!.pillsRemaining}');
    _thresholdC = TextEditingController(text: '${e?.lowStockThreshold ?? 5}');
    _notesC = TextEditingController(text: e?.notes ?? '');
    _start = e?.startDate ?? dateOnly(DateTime.now());
    _times = e == null ? [const TimeOfDay(hour: 8, minute: 0)] : e.timeList;
    _weekdays = Set<int>.from(e?.weekdays ?? const <int>[]);
    _active = e?.active ?? true;
  }

  @override
  void dispose() {
    _nameC.dispose();
    _doseC.dispose();
    _perDoseC.dispose();
    _durationC.dispose();
    _stockC.dispose();
    _thresholdC.dispose();
    _notesC.dispose();
    super.dispose();
  }

  Future<void> _addTime() async {
    final t = await pickTime(context, const TimeOfDay(hour: 8, minute: 0));
    if (t == null) return;
    final exists = _times.any((x) => x.hour == t.hour && x.minute == t.minute);
    if (exists) return;
    setState(() {
      _times.add(t);
      _times.sort((a, b) => hmMinutes(a) - hmMinutes(b));
    });
  }

  void _toggleWeekday(int d) {
    setState(() {
      if (_weekdays.contains(d)) {
        _weekdays.remove(d);
      } else {
        _weekdays.add(d);
      }
      if (_weekdays.length == 7) _weekdays.clear(); // كل الأيام = يومياً
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_times.isEmpty) {
      showSnack(context, 'أضف ساعة واحدة على الأقل لأخذ الدواء');
      return;
    }
    final state = context.read<AppState>();
    final nav = Navigator.of(context);
    final e = widget.existing;

    final stockText = _stockC.text.trim();
    final m = Medicine(
      id: e?.id,
      name: _nameC.text.trim(),
      dose: _doseC.text.trim(),
      pillsPerDose: parseInt(_perDoseC.text) ?? 1,
      durationDays: parseInt(_durationC.text) ?? 0,
      startDate: _start,
      times: _times.map(hmToString).toList(),
      weekdays: _weekdays.toList()..sort(),
      notes: _notesC.text.trim(),
      active: _active,
      pillsRemaining: stockText.isEmpty ? null : parseInt(stockText),
      lowStockThreshold: parseInt(_thresholdC.text) ?? 5,
    );
    setState(() => _saving = true);
    await state.saveMedicine(m);
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'تعديل الدواء' : 'إضافة دواء')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('اسم الدواء', icon: Icons.medication_outlined),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'اكتب اسم الدواء' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _doseC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('الجرعة',
                  icon: Icons.local_pharmacy_outlined,
                  hint: 'مثال: قرص واحد بعد الأكل'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _perDoseC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration('عدد الأقراص في الجرعة الواحدة',
                  icon: Icons.numbers),
              validator: (v) {
                final n = parseInt(v);
                if (n == null || n < 1) return 'اكتب رقمًا من 1 فأكثر';
                return null;
              },
            ),
            const SizedBox(height: 20),
            Text('ساعات أخذ الدواء',
                style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final t in _times)
                  InputChip(
                    avatar: const Icon(Icons.access_time, size: 18),
                    label: Text(formatTimeOfDay(t)),
                    onDeleted: () => setState(() => _times.remove(t)),
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 18),
                  label: const Text('إضافة ساعة'),
                  onPressed: _addTime,
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text('أيام الأسبوع', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                ChoiceChip(
                  label: const Text('كل يوم'),
                  selected: _weekdays.isEmpty,
                  onSelected: (_) => setState(() => _weekdays.clear()),
                ),
                for (final d in kWeekdayDisplayOrder)
                  FilterChip(
                    label: Text(weekdayName(d)),
                    selected: _weekdays.contains(d),
                    onSelected: (_) => _toggleWeekday(d),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            InkWell(
              onTap: () async {
                final d = await pickDate(context, _start);
                if (d != null) setState(() => _start = d);
              },
              child: InputDecorator(
                decoration: fieldDecoration('تاريخ بداية الدواء', icon: Icons.event_outlined),
                child: Text(formatDateWithDay(_start)),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _durationC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration('مدة الدواء بالأيام',
                  icon: Icons.timelapse,
                  hint: '0 = مستمر بدون نهاية',
                  suffixText: 'يوم'),
              validator: (v) {
                final n = parseInt(v);
                if (n == null || n < 0) return 'اكتب 0 للمستمر أو عدد الأيام';
                return null;
              },
            ),
            const SizedBox(height: 20),
            Text('مخزون العلبة', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            TextFormField(
              controller: _stockC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration('عدد الأقراص المتبقية (اختياري)',
                  icon: Icons.inventory_2_outlined,
                  hint: 'اتركه فارغًا لو لا تريد تتبع المخزون'),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return null;
                final n = parseInt(v);
                if (n == null || n < 0) return 'اكتب رقمًا صحيحًا';
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _thresholdC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration('نبّهني عندما يتبقى',
                  icon: Icons.warning_amber_rounded, suffixText: 'قرص أو أقل'),
              validator: (v) {
                final n = parseInt(v);
                if (n == null || n < 0) return 'اكتب رقمًا صحيحًا';
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesC,
              maxLines: 3,
              decoration: fieldDecoration('ملاحظات (اختياري)', icon: Icons.notes),
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('الدواء نشط'),
              subtitle: const Text('أوقفه ليصبح "منتهي" وتتوقف تنبيهاته'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
