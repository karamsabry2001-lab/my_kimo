import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/association.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../utils/share_texts.dart';
import 'association_form_screen.dart';

/// تفاصيل الجمعية: جدول الأقساط الشهرية مع تحديد المدفوع.
class AssociationDetailScreen extends StatelessWidget {
  final int associationId;

  const AssociationDetailScreen({super.key, required this.associationId});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final a = state.associationById(associationId);
    if (a == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('تم حذف هذه الجمعية')),
      );
    }
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(a.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'مشاركة',
            onPressed: () => Share.share(associationShareText(a)),
          ),
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'تعديل',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) =>
                    AssociationFormScreen(existing: a, initialOwner: a.owner),
              ),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: scheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    a.ownerLabel,
                    style: TextStyle(
                      color: scheme.onPrimaryContainer,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _row(context, 'القسط الشهري', formatMoney(a.monthlyAmount)),
                  _row(context, 'إجمالي مبلغ القبض', formatMoney(a.totalAmount)),
                  _row(context, 'المدفوع', '${formatMoney(a.paidAmount)} (${a.paidCount} من ${a.totalMonths})'),
                  _row(context, 'المتبقي', formatMoney(a.remainingAmount)),
                  _row(context, 'تاريخ القبض',
                      '${formatDate(a.collectDate)} (الشهر ${a.collectMonth})'),
                  if (a.notes.isNotEmpty) _row(context, 'ملاحظات', a.notes),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'جدول الأقساط',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          for (var month = 1; month <= a.totalMonths; month++)
            _MonthTile(association: a, month: month),
        ],
      ),
    );
  }

  Widget _row(BuildContext context, String label, String value) {
    final c = Theme.of(context).colorScheme.onPrimaryContainer;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 120, child: Text(label, style: TextStyle(color: c))),
          Expanded(
            child: Text(value,
                style: TextStyle(color: c, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

class _MonthTile extends StatelessWidget {
  final Association association;
  final int month;

  const _MonthTile({required this.association, required this.month});

  @override
  Widget build(BuildContext context) {
    final a = association;
    final paid = a.paidMonths.contains(month);
    final due = a.dueDateOf(month);
    final isCollect = a.collectMonth == month;
    final overdue = !paid && daysBetween(DateTime.now(), due) < 0;
    final scheme = Theme.of(context).colorScheme;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: isCollect ? scheme.tertiaryContainer : null,
      child: CheckboxListTile(
        value: paid,
        onChanged: (_) =>
            context.read<AppState>().toggleAssociationPaid(a, month),
        title: Text('القسط رقم $month${isCollect ? '  🎉 شهر القبض' : ''}'),
        subtitle: Text(
          '${formatDateWithDay(due)}\n${formatMoney(a.monthlyAmount)}'
          '${overdue ? '  •  متأخر' : ''}',
          style: TextStyle(color: overdue ? scheme.error : null),
        ),
        isThreeLine: true,
        controlAffinity: ListTileControlAffinity.leading,
      ),
    );
  }
}
