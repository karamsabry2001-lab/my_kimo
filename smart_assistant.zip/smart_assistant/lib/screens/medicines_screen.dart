import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/medicine.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../utils/share_texts.dart';
import '../widgets/common.dart';
import 'medicine_form_screen.dart';

/// قسم الأدوية والجرعات.
class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});

  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  String _query = '';
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final q = _query.trim();

    final list = state.medicines.where((m) {
      if (_filter == 'active' && !m.isActive) return false;
      if (_filter == 'ended' && m.isActive) return false;
      if (_filter == 'low' && !m.needsRefill) return false;
      if (q.isNotEmpty && !m.name.contains(q) && !m.notes.contains(q) && !m.dose.contains(q)) {
        return false;
      }
      return true;
    }).toList();

    final activeMeds = state.medicines.where((m) => m.isActive).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('الأدوية والجرعات'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'مشاركة جدول الأدوية',
            onPressed: () => Share.share(medicinesSummaryText(activeMeds)),
          ),
          const ThemeToggleButton(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const MedicineFormScreen()),
        ),
        icon: const Icon(Icons.add),
        label: const Text('إضافة دواء'),
      ),
      body: Column(
        children: [
          AppSearchField(
            hint: 'ابحث باسم الدواء',
            onChanged: (v) => setState(() => _query = v),
          ),
          ChoiceRow<String>(
            options: const {
              'all': 'الكل',
              'active': 'نشط',
              'ended': 'منتهي',
              'low': 'اقترب النفاد',
            },
            value: _filter,
            onChanged: (v) => setState(() => _filter = v),
          ),
          Expanded(
            child: state.medicines.isEmpty
                ? const EmptyState(
                    icon: Icons.medication_outlined,
                    message: 'لا توجد أدوية مسجلة.\nاضغط "إضافة دواء" للبدء.',
                  )
                : list.isEmpty
                    ? const EmptyState(
                        icon: Icons.search_off, message: 'لا توجد نتائج مطابقة')
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _MedicineCard(medicine: list[i]),
                      ),
          ),
        ],
      ),
    );
  }
}

class _MedicineCard extends StatelessWidget {
  final Medicine medicine;
  const _MedicineCard({required this.medicine});

  @override
  Widget build(BuildContext context) {
    final m = medicine;
    final scheme = Theme.of(context).colorScheme;
    final active = m.isActive;
    final low = m.isLowStock && active;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.medication, color: active ? scheme.primary : scheme.outline),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    m.name,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                StatusChip(
                  label: active ? 'نشط' : 'منتهي',
                  color: active ? Colors.green : Colors.grey,
                ),
                PopupMenuButton<String>(
                  onSelected: (v) => _onMenu(context, v),
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'edit', child: Text('تعديل')),
                    const PopupMenuItem(value: 'share', child: Text('مشاركة')),
                    PopupMenuItem(
                      value: 'toggle',
                      child: Text(m.active ? 'تحديد كمنتهي' : 'تفعيل الدواء'),
                    ),
                    const PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              ],
            ),
            if (m.dose.isNotEmpty)
              InfoLine(icon: Icons.local_pharmacy_outlined, text: 'الجرعة: ${m.dose}'),
            InfoLine(
              icon: Icons.schedule,
              text: 'المواعيد: ${m.timeList.map(formatTimeOfDay).join('، ')}',
            ),
            InfoLine(icon: Icons.calendar_month_outlined, text: 'الأيام: ${m.daysLabel}'),
            InfoLine(icon: Icons.timelapse, text: m.durationLabel),
            if (m.notes.isNotEmpty) InfoLine(icon: Icons.notes, text: m.notes),
            if (m.pillsRemaining != null) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: low
                      ? Colors.orange.withAlpha(40)
                      : scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      low ? Icons.warning_amber_rounded : Icons.inventory_2_outlined,
                      color: low ? Colors.orange.shade800 : scheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'المتبقي: ${m.pillsRemaining}'
                        '${m.stockDaysLeft == null ? '' : ' (يكفي حوالي ${m.stockDaysLeft} يوم)'}'
                        '${low ? '\nاقترب نفاد العلبة!' : ''}',
                        style: TextStyle(
                          fontWeight: low ? FontWeight.bold : FontWeight.normal,
                          color: low ? Colors.orange.shade900 : null,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                if (m.pillsRemaining != null)
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed: () async {
                        await context.read<AppState>().takeDose(m);
                        if (context.mounted) {
                          showSnack(context, 'تم خصم جرعة من ${m.name}');
                        }
                      },
                      icon: const Icon(Icons.check),
                      label: const Text('أخذت جرعة'),
                    ),
                  ),
                if (m.pillsRemaining != null) const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _refill(context),
                    icon: const Icon(Icons.add_box_outlined),
                    label: const Text('إضافة علبة'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _refill(BuildContext context) async {
    final state = context.read<AppState>();
    final c = TextEditingController();
    final count = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة إلى المخزون'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: fieldDecoration('عدد الأقراص / الوحدات المضافة'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, parseInt(c.text)),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    c.dispose();
    if (count != null && count > 0) {
      await state.refillMedicine(medicine, count);
    }
  }

  Future<void> _onMenu(BuildContext context, String value) async {
    final m = medicine;
    final state = context.read<AppState>();
    switch (value) {
      case 'edit':
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => MedicineFormScreen(existing: m)),
        );
        break;
      case 'share':
        Share.share(medicineShareText(m));
        break;
      case 'toggle':
        await state.setMedicineActive(m, !m.active);
        break;
      case 'delete':
        final ok = await confirmDialog(
          context,
          title: 'حذف الدواء',
          message: 'هل تريد حذف "${m.name}" نهائيًا؟',
        );
        if (ok && m.id != null) await state.deleteMedicine(m.id!);
        break;
    }
  }
}
