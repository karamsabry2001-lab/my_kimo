import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/document_item.dart';
import '../providers/app_state.dart';
import '../services/file_service.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'document_form_screen.dart';

/// أرشيف الروشتات والمستندات الطبية.
class ArchiveScreen extends StatefulWidget {
  const ArchiveScreen({super.key});

  @override
  State<ArchiveScreen> createState() => _ArchiveScreenState();
}

class _ArchiveScreenState extends State<ArchiveScreen> {
  String _query = '';
  String _category = 'all';

  Future<void> _add() async {
    final source = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('تصوير بالكاميرا'),
              onTap: () => Navigator.pop(ctx, 'camera'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('اختيار صورة من المعرض'),
              onTap: () => Navigator.pop(ctx, 'gallery'),
            ),
            ListTile(
              leading: const Icon(Icons.attach_file),
              title: const Text('اختيار ملف (PDF أو غيره)'),
              onTap: () => Navigator.pop(ctx, 'file'),
            ),
          ],
        ),
      ),
    );
    if (source == null || !mounted) return;

    String? path;
    String name = '';
    try {
      if (source == 'file') {
        final res = await FilePicker.platform.pickFiles(type: FileType.any);
        if (res != null && res.files.single.path != null) {
          path = res.files.single.path;
          name = res.files.single.name;
        }
      } else {
        final x = await ImagePicker().pickImage(
          source: source == 'camera' ? ImageSource.camera : ImageSource.gallery,
          imageQuality: 85,
        );
        if (x != null) {
          path = x.path;
          name = x.name;
        }
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذر اختيار الملف');
      return;
    }
    if (path == null || !mounted) return;
    final String chosenPath = path;
    final String chosenName = name;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            DocumentFormScreen(pickedPath: chosenPath, pickedName: chosenName),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final q = _query.trim();
    final list = state.documents.where((d) {
      if (_category != 'all' && d.category != _category) return false;
      if (q.isNotEmpty && !d.title.contains(q) && !d.notes.contains(q)) return false;
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('أرشيف الروشتات والمستندات'),
        centerTitle: true,
        actions: const [ThemeToggleButton()],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add_a_photo_outlined),
        label: const Text('إضافة مستند'),
      ),
      body: Column(
        children: [
          AppSearchField(
            hint: 'ابحث بعنوان المستند أو الملاحظات',
            onChanged: (v) => setState(() => _query = v),
          ),
          ChoiceRow<String>(
            options: {'all': 'الكل', ...kDocCategories},
            value: _category,
            onChanged: (v) => setState(() => _category = v),
          ),
          Expanded(
            child: state.documents.isEmpty
                ? const EmptyState(
                    icon: Icons.folder_open_outlined,
                    message: 'الأرشيف فارغ.\nأضف صور الروشتات والتقارير والتحاليل.',
                  )
                : list.isEmpty
                    ? const EmptyState(
                        icon: Icons.search_off, message: 'لا توجد نتائج مطابقة')
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _DocumentCard(document: list[i]),
                      ),
          ),
        ],
      ),
    );
  }
}

class _DocumentCard extends StatelessWidget {
  final DocumentItem document;
  const _DocumentCard({required this.document});

  Future<void> _open(BuildContext context) async {
    final file = await FileService.resolve(document.fileName);
    if (!await file.exists()) {
      if (context.mounted) showSnack(context, 'الملف غير موجود');
      return;
    }
    final res = await OpenFilex.open(file.path);
    if (res.type != ResultType.done && context.mounted) {
      showSnack(context, 'لا يوجد تطبيق لفتح هذا الملف');
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = document;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _open(context),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              _Thumb(document: d),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 2),
                    Text('${d.categoryLabel} • ${formatDate(d.date)}'),
                    if (d.notes.isNotEmpty)
                      Text(
                        d.notes,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurfaceVariant),
                      ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (v) => _onMenu(context, v),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'open', child: Text('فتح')),
                  PopupMenuItem(value: 'share', child: Text('مشاركة الملف')),
                  PopupMenuItem(value: 'edit', child: Text('تعديل البيانات')),
                  PopupMenuItem(value: 'delete', child: Text('حذف')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onMenu(BuildContext context, String value) async {
    final d = document;
    final state = context.read<AppState>();
    switch (value) {
      case 'open':
        await _open(context);
        break;
      case 'share':
        final file = await FileService.resolve(d.fileName);
        if (await file.exists()) {
          await Share.shareXFiles([XFile(file.path)], text: d.title);
        } else if (context.mounted) {
          showSnack(context, 'الملف غير موجود');
        }
        break;
      case 'edit':
        if (context.mounted) {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => DocumentFormScreen(existing: d)),
          );
        }
        break;
      case 'delete':
        final ok = await confirmDialog(
          context,
          title: 'حذف المستند',
          message: 'سيتم حذف "${d.title}" والملف المرفق نهائيًا.',
        );
        if (ok) await state.deleteDocument(d);
        break;
    }
  }
}

class _Thumb extends StatelessWidget {
  final DocumentItem document;
  const _Thumb({required this.document});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    Widget icon(IconData i) => Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: scheme.primaryContainer,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(i, color: scheme.onPrimaryContainer, size: 30),
        );

    if (document.isImage) {
      return FutureBuilder<File>(
        future: FileService.resolve(document.fileName),
        builder: (context, snap) {
          if (!snap.hasData) return icon(Icons.image_outlined);
          return ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(
              snap.data!,
              width: 60,
              height: 60,
              fit: BoxFit.cover,
              cacheWidth: 150,
              errorBuilder: (_, __, ___) => icon(Icons.broken_image_outlined),
            ),
          );
        },
      );
    }
    return icon(document.isPdf ? Icons.picture_as_pdf_outlined : Icons.insert_drive_file_outlined);
  }
}
