import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/association.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'settings_screen.dart';

/// الشاشة الرئيسية: ملخص سريع لأقرب دواء وموعد وحالة الجمعيات.
class DashboardScreen extends StatelessWidget {
  final ValueChanged<int> onNavigate;

  const DashboardScreen({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final now = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: const Text('مساعدي الشخصي'),
        centerTitle: true,
        actions: [
          const ThemeToggleButton(),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'الإعدادات',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: !state.loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _GreetingCard(now: now),
                const SizedBox(height: 12),
                _NextDoseCard(onTap: () => onNavigate(3)),
                const SizedBox(height: 12),
                _NextAppointmentCard(onTap: () => onNavigate(2)),
                const SizedBox(height: 12),
                _AssociationsCard(onTap: () => onNavigate(1)),
                if (state.lowStockMedicines.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  _LowStockCard(onTap: () => onNavigate(3)),
                ],
                const SizedBox(height: 24),
              ],
            ),
    );
  }
}

class _GreetingCard extends StatelessWidget {
  final DateTime now;
  const _GreetingCard({required this.now});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hour = now.hour;
    final greeting = hour < 12 ? 'صباح الخير ☀️' : (hour < 18 ? 'مساء الخير 🌤️' : 'مساء الخير 🌙');
    return Card(
      color: scheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              greeting,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: scheme.onPrimaryContainer,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              formatDateWithDay(now),
              style: TextStyle(color: scheme.onPrimaryContainer),
            ),
          ],
        ),
      ),
    );
  }
}

class _DashCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color? color;
  final Widget child;
  final VoidCallback? onTap;

  const _DashCard({
    required this.icon,
    required this.title,
    required this.child,
    this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: c.withAlpha(40),
                    child: Icon(icon, color: c, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Icon(Icons.chevron_left),
                ],
              ),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ),
      ),
    );
  }
}

class _NextDoseCard extends StatelessWidget {
  final VoidCallback onTap;
  const _NextDoseCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final next = context.watch<AppState>().nextDose;
    return _DashCard(
      icon: Icons.medication_outlined,
      title: 'أقرب ميعاد دواء',
      onTap: onTap,
      child: next == null
          ? const Text('لا توجد جرعات قادمة. أضف دواءً من قسم الأدوية.')
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  next.medicine.name,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                if (next.medicine.dose.isNotEmpty) Text(next.medicine.dose),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Chip(
                      avatar: const Icon(Icons.access_time, size: 18),
                      label: Text(
                        '${weekdayName(next.time.weekday)} - ${formatTime(next.time)}',
                      ),
                    ),
                    Chip(label: Text(relativeFromNow(next.time))),
                  ],
                ),
              ],
            ),
    );
  }
}

class _NextAppointmentCard extends StatelessWidget {
  final VoidCallback onTap;
  const _NextAppointmentCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final next = context.watch<AppState>().nextAppointment;
    return _DashCard(
      icon: Icons.local_hospital_outlined,
      color: Colors.redAccent,
      title: 'ميعاد المستشفى القادم',
      onTap: onTap,
      child: next == null
          ? const Text('لا توجد مواعيد قادمة.')
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  next.doctor,
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                if (next.title.isNotEmpty) Text(next.title),
                InfoLine(
                  icon: Icons.event,
                  text: formatDateWithDay(next.dateTime),
                ),
                InfoLine(icon: Icons.access_time, text: formatTime(next.dateTime)),
                if (next.place.isNotEmpty)
                  InfoLine(icon: Icons.place_outlined, text: next.place),
                const SizedBox(height: 8),
                Chip(label: Text(relativeFromNow(next.dateTime))),
              ],
            ),
    );
  }
}

class _AssociationsCard extends StatelessWidget {
  final VoidCallback onTap;
  const _AssociationsCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return _DashCard(
      icon: Icons.savings_outlined,
      color: Colors.amber.shade800,
      title: 'حالة الجمعيات الشهرية',
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ownerSection(context, 'حسابي', state.associationsOf(Association.ownerMe)),
          const Divider(height: 24),
          _ownerSection(
              context, 'حساب الوالدة', state.associationsOf(Association.ownerMother)),
        ],
      ),
    );
  }

  Widget _ownerSection(BuildContext context, String label, List<Association> list) {
    final active = list.where((a) => !a.isCompleted).toList();
    final titleStyle = Theme.of(context)
        .textTheme
        .titleSmall
        ?.copyWith(fontWeight: FontWeight.bold);

    if (active.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: titleStyle),
          const SizedBox(height: 4),
          const Text('لا توجد جمعيات جارية'),
        ],
      );
    }

    var monthly = 0.0;
    Association? nearestDue;
    Association? nearestCollect;
    for (final a in active) {
      monthly += a.monthlyAmount;
      final due = a.nextDueDate!;
      if (nearestDue == null || due.isBefore(nearestDue.nextDueDate!)) {
        nearestDue = a;
      }
      if (!a.collectDatePassed) {
        if (nearestCollect == null || a.collectDate.isBefore(nearestCollect.collectDate)) {
          nearestCollect = a;
        }
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: titleStyle),
        InfoLine(
          icon: Icons.groups_outlined,
          text:
              '${active.length} جمعية جارية • الأقساط الشهرية ${formatMoney(monthly)}',
        ),
        if (nearestDue != null)
          InfoLine(
            icon: Icons.payments_outlined,
            text:
                'أقرب قسط: ${nearestDue.name} - ${formatDate(nearestDue.nextDueDate!)} '
                '(${dayDistanceText(nearestDue.nextDueDate!)}) - ${formatMoney(nearestDue.monthlyAmount)}',
          ),
        if (nearestCollect != null)
          InfoLine(
            icon: Icons.celebration_outlined,
            text:
                'أقرب قبض: ${nearestCollect.name} - ${formatDate(nearestCollect.collectDate)} '
                '- ${formatMoney(nearestCollect.totalAmount)}',
          ),
      ],
    );
  }
}

class _LowStockCard extends StatelessWidget {
  final VoidCallback onTap;
  const _LowStockCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().lowStockMedicines;
    return _DashCard(
      icon: Icons.warning_amber_rounded,
      color: Colors.orange.shade800,
      title: 'اقتراب نفاذ الأدوية',
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final m in list)
            InfoLine(
              icon: Icons.medication_liquid_outlined,
              text: '${m.name}: متبقي ${m.pillsRemaining}'
                  '${m.stockDaysLeft == null ? '' : ' (يكفي حوالي ${m.stockDaysLeft} يوم)'}',
            ),
        ],
      ),
    );
  }
}
