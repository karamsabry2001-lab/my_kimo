import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/association.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../utils/share_texts.dart';
import '../widgets/common.dart';
import 'association_detail_screen.dart';
import 'association_form_screen.dart';

/// قسم الجمعيات الشهرية: تبويبان (حسابي / حساب الوالدة).
class AssociationsScreen extends StatefulWidget {
  const AssociationsScreen({super.key});

  @override
  State<AssociationsScreen> createState() => _AssociationsScreenState();
}

class _AssociationsScreenState extends State<AssociationsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  String _query = '';
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  String get _currentOwner =>
      _tab.index == 0 ? Association.ownerMe : Association.ownerMother;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('الجمعيات الشهرية'),
        centerTitle: true,
        actions: const [ThemeToggleButton()],
        bottom: TabBar(
          controller: _tab,
          tabs: const [Tab(text: 'حسابي'), Tab(text: 'حساب الوالدة')],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => AssociationFormScreen(initialOwner: _currentOwner),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('إضافة جمعية'),
      ),
      body: Column(
        children: [
          AppSearchField(
            hint: 'ابحث باسم الجمعية أو الملاحظات',
            onChanged: (v) => setState(() => _query = v),
          ),
          ChoiceRow<String>(
            options: const {'all': 'الكل', 'active': 'جارية', 'done': 'مكتملة'},
            value: _filter,
            onChanged: (v) => setState(() => _filter = v),
          ),
          Expanded(
            child: TabBarView(
              controller: _tab,
              children: [
                _buildList(state, Association.ownerMe),
                _buildList(state, Association.ownerMother),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(AppState state, String owner) {
    final all = state.associationsOf(owner);
    if (all.isEmpty) {
      return const EmptyState(
        icon: Icons.groups_outlined,
        message: 'لا توجد جمعيات هنا بعد.\nاضغط "إضافة جمعية" للبدء.',
      );
    }
    final q = _query.trim();
    final list = all.where((a) {
      if (_filter == 'active' && a.isCompleted) return false;
      if (_filter == 'done' && !a.isCompleted) return false;
      if (q.isNotEmpty && !a.name.contains(q) && !a.notes.contains(q)) {
        return false;
      }
      return true;
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      children: [
        _SummaryCard(list: all),
        const SizedBox(height: 12),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('لا توجد نتائج مطابقة')),
          ),
        for (final a in list) _AssociationCard(association: a),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final List<Association> list;
  const _SummaryCard({required this.list});

  @override
  Widget build(BuildContext context) {
    final active = list.where((a) => !a.isCompleted).toList();
    var monthly = 0.0;
    var remaining = 0.0;
    for (final a in active) {
      monthly += a.monthlyAmount;
      remaining += a.remainingAmount;
    }
    final scheme = Theme.of(context).colorScheme;
    Widget stat(String label, String value) => Expanded(
          child: Column(
            children: [
              Text(
                value,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: scheme.onSecondaryContainer,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: scheme.onSecondaryContainer),
              ),
            ],
          ),
        );

    return Card(
      color: scheme.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Row(
          children: [
            stat('جمعيات جارية', '${active.length}'),
            stat('الأقساط الشهرية', formatMoney(monthly)),
            stat('المتبقي للدفع', formatMoney(remaining)),
          ],
        ),
      ),
    );
  }
}

class _AssociationCard extends StatelessWidget {
  final Association association;
  const _AssociationCard({required this.association});

  @override
  Widget build(BuildContext context) {
    final a = association;
    final scheme = Theme.of(context).colorScheme;
    final next = a.nextDueDate;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => AssociationDetailScreen(associationId: a.id!),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      a.name,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                  if (a.isCompleted)
                    const StatusChip(label: 'مكتملة', color: Colors.green),
                  PopupMenuButton<String>(
                    onSelected: (v) => _onMenu(context, v),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('تعديل')),
                      PopupMenuItem(value: 'share', child: Text('مشاركة')),
                      PopupMenuItem(value: 'delete', child: Text('حذف')),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  minHeight: 8,
                  value: a.totalMonths == 0 ? 0 : a.paidCount / a.totalMonths,
                  backgroundColor: scheme.surfaceContainerHighest,
                ),
              ),
              const SizedBox(height: 6),
              Text('تم دفع ${a.paidCount} من ${a.totalMonths} شهر'),
              InfoLine(
                icon: Icons.payments_outlined,
                text: 'القسط الشهري: ${formatMoney(a.monthlyAmount)}',
              ),
              if (next != null)
                InfoLine(
                  icon: Icons.event_available_outlined,
                  text: 'القسط القادم: ${formatDate(next)} (${dayDistanceText(next)})',
                ),
              InfoLine(
                icon: Icons.celebration_outlined,
                text:
                    'دور القبض: الشهر ${a.collectMonth} - ${formatDate(a.collectDate)}'
                    '${a.collectDatePassed ? ' (فات الموعد)' : ''}',
              ),
              InfoLine(
                icon: Icons.account_balance_wallet_outlined,
                text: 'مبلغ القبض: ${formatMoney(a.totalAmount)}',
              ),
              if (a.notes.isNotEmpty)
                InfoLine(icon: Icons.notes, text: a.notes),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onMenu(BuildContext context, String value) async {
    final a = association;
    switch (value) {
      case 'edit':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) =>
                AssociationFormScreen(existing: a, initialOwner: a.owner),
          ),
        );
        break;
      case 'share':
        Share.share(associationShareText(a));
        break;
      case 'delete':
        final state = context.read<AppState>();
        final ok = await confirmDialog(
          context,
          title: 'حذف الجمعية',
          message: 'هل تريد حذف "${a.name}" نهائيًا؟',
        );
        if (ok && a.id != null) await state.deleteAssociation(a.id!);
        break;
    }
  }
}
