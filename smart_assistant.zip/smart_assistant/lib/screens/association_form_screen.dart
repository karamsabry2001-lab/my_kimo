import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/association.dart';
import '../providers/app_state.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// نموذج إضافة / تعديل جمعية.
class AssociationFormScreen extends StatefulWidget {
  final Association? existing;
  final String initialOwner;

  const AssociationFormScreen({
    super.key,
    this.existing,
    this.initialOwner = Association.ownerMe,
  });

  @override
  State<AssociationFormScreen> createState() => _AssociationFormScreenState();
}

class _AssociationFormScreenState extends State<AssociationFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameC;
  late final TextEditingController _amountC;
  late final TextEditingController _monthsC;
  late final TextEditingController _collectC;
  late final TextEditingController _notesC;
  late String _owner;
  late DateTime _startDate;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _owner = e?.owner ?? widget.initialOwner;
    _nameC = TextEditingController(text: e?.name ?? '');
    _amountC = TextEditingController(
        text: e == null ? '' : formatNumber(e.monthlyAmount).replaceAll(',', ''));
    _monthsC = TextEditingController(text: e == null ? '10' : '${e.totalMonths}');
    _collectC = TextEditingController(text: e == null ? '1' : '${e.collectMonth}');
    _notesC = TextEditingController(text: e?.notes ?? '');
    _startDate = e?.startDate ?? dateOnly(DateTime.now());
  }

  @override
  void dispose() {
    _nameC.dispose();
    _amountC.dispose();
    _monthsC.dispose();
    _collectC.dispose();
    _notesC.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final state = context.read<AppState>();
    final nav = Navigator.of(context);
    final total = parseInt(_monthsC.text)!;
    final collect = parseInt(_collectC.text)!;
    final e = widget.existing;

    final a = Association(
      id: e?.id,
      owner: _owner,
      name: _nameC.text.trim(),
      monthlyAmount: parseDouble(_amountC.text)!,
      totalMonths: total,
      startDate: _startDate,
      collectMonth: collect,
      notes: _notesC.text.trim(),
      paidMonths: (e?.paidMonths ?? []).where((m) => m <= total).toList(),
    );
    setState(() => _saving = true);
    await state.saveAssociation(a);
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'تعديل الجمعية' : 'إضافة جمعية')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('الحساب'),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(
                  value: Association.ownerMe,
                  label: Text('حسابي'),
                  icon: Icon(Icons.person_outline),
                ),
                ButtonSegment(
                  value: Association.ownerMother,
                  label: Text('حساب الوالدة'),
                  icon: Icon(Icons.people_outline),
                ),
              ],
              selected: {_owner},
              onSelectionChanged: (s) => setState(() => _owner = s.first),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _nameC,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration('اسم الجمعية', icon: Icons.label_outline),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'اكتب اسم الجمعية' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _amountC,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: fieldDecoration('القسط الشهري',
                  icon: Icons.payments_outlined, suffixText: kCurrency),
              validator: (v) {
                final n = parseDouble(v);
                if (n == null || n <= 0) return 'اكتب مبلغًا صحيحًا';
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _monthsC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration('عدد الأشهر',
                  icon: Icons.calendar_month_outlined, suffixText: 'شهر'),
              validator: (v) {
                final n = parseInt(v);
                if (n == null || n < 1 || n > 120) return 'اكتب رقمًا من 1 إلى 120';
                return null;
              },
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () async {
                final d = await pickDate(context, _startDate);
                if (d != null) setState(() => _startDate = d);
              },
              child: InputDecorator(
                decoration:
                    fieldDecoration('تاريخ أول قسط', icon: Icons.event_outlined),
                child: Text(formatDateWithDay(_startDate)),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _collectC,
              keyboardType: TextInputType.number,
              decoration: fieldDecoration(
                'دور القبض (رقم الشهر)',
                icon: Icons.celebration_outlined,
                hint: 'مثال: 3 يعني تقبض في الشهر الثالث',
              ),
              validator: (v) {
                final n = parseInt(v);
                final total = parseInt(_monthsC.text) ?? 1;
                if (n == null || n < 1 || n > total) {
                  return 'اكتب رقمًا من 1 إلى $total';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesC,
              maxLines: 3,
              decoration: fieldDecoration('ملاحظات (اختياري)', icon: Icons.notes),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
