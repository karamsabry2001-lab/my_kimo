# تعديل Gradle المطلوب (لحزمة التنبيهات)

حزمة `flutter_local_notifications` تحتاج تفعيل **core library desugaring**.
افتح ملف `android/app/build.gradle` **أو** `android/app/build.gradle.kts`
(حسب ما أنشأه Flutter عندك) وعدّله كالتالي:

## إذا كان الملف `build.gradle.kts` (Kotlin)

```kotlin
android {
    // ... باقي الإعدادات كما هي
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        // اترك sourceCompatibility / targetCompatibility كما هما
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
```

## إذا كان الملف `build.gradle` (Groovy)

```groovy
android {
    // ... باقي الإعدادات كما هي
    compileOptions {
        coreLibraryDesugaringEnabled true
        // اترك sourceCompatibility / targetCompatibility كما هما
    }
}

dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'
}
```

> لو لم يكن في ملفك قسم `dependencies { }` فأضِفه في آخر الملف (خارج قسم `android { }`).

## ملاحظات
- `minSdk` الافتراضي في Flutter (21 أو أعلى) مناسب.
- لو ظهر خطأ يطلب `compileSdk` أعلى، ارفعه (مثلاً 35) من نفس الملف.
